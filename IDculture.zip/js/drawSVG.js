(function($) {
      $(document).ready(function(){
            var $svg = $('#logo_svg').drawsvg();

            $svg.drawsvg('animate');


});
      
})(jQuery);
