(function($){
      $(document).ready(function () {
            $('.about_box').click(function(){
                  location.assign("../html/about.html");
            });
            $('.service_box').click(function(){
                  location.assign("../html/service.html");
            });
      });
})(jQuery);